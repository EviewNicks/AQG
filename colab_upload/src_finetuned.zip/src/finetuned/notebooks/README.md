# Fine-Tuning Notebooks

## Overview

Notebooks untuk fine-tuning IndoT5 model untuk task Automatic Question Generation (AQG).

## Notebooks

### 1. `01_setup_and_validation.ipynb`
Setup awal dan validasi environment untuk fine-tuning.

### 2. `02_domain_adaptation.ipynb`
Domain adaptation (Stage 1) - optional, bisa skip langsung ke Stage 2.

### 3. `03_task_specific_training.ipynb` (DEPRECATED)
**Status**: ⚠️ DEPRECATED - Mengandung code duplication

**Masalah**:
- ~200 baris code
- Duplikasi logic dari `task_trainer.py`
- Hard to maintain (bug fix harus di 2 tempat)
- Tidak menggunakan modules yang sudah ada

**Jangan gunakan notebook ini!** Gunakan `03_task_specific_training_v2.ipynb` sebagai gantinya.

### 4. `03_task_specific_training_v2.ipynb` ✅ RECOMMENDED
**Status**: ✅ PRODUCTION READY - Clean, no duplication

**Improvements**:
- ~50 baris code (simplified 75%)
- Menggunakan `task_trainer.py` untuk semua logic
- Menggunakan `model_loader.py` helper
- Bug fix applied: `label_pad_token_id=-100`
- Easy to maintain (bug fix hanya di 1 tempat)
- Clean separation: notebook = orchestration, modules = business logic

**Key Features**:
```python
# Load model (3 lines instead of 30!)
from src.finetuned.utils.model_loader import load_model_with_lora
peft_model, tokenizer = load_model_with_lora()

# Training (10 lines instead of 50!)
from src.finetuned.training.task_trainer import TaskSpecificTrainer
trainer = TaskSpecificTrainer(model=peft_model, tokenizer=tokenizer, ...)
results = trainer.train(train_dataset, val_dataset)
```

## Architecture

```
src/finetuned/
├── notebooks/
│   ├── 01_setup_and_validation.ipynb
│   ├── 02_domain_adaptation.ipynb
│   ├── 03_task_specific_training.ipynb      ❌ DEPRECATED
│   └── 03_task_specific_training_v2.ipynb   ✅ USE THIS
├── training/
│   ├── task_trainer.py          # Business logic (reusable)
│   └── domain_trainer.py
├── utils/
│   ├── model_loader.py          # Helper functions
│   └── __init__.py
├── data/
│   └── dataset_loader.py
└── evaluation/
    ├── metrics_calculator.py
    └── model_evaluator.py
```

## Best Practices

### ✅ DO:
- Use `03_task_specific_training_v2.ipynb` for training
- Keep business logic in `.py` modules
- Use notebooks only for orchestration and visualization
- Import and call functions from modules

### ❌ DON'T:
- Use `03_task_specific_training.ipynb` (deprecated)
- Write business logic directly in notebooks
- Duplicate code between notebooks and modules
- Copy-paste code from modules to notebooks

## Migration Guide

If you're using the old notebook (`03_task_specific_training.ipynb`), migrate to v2:

**Before** (old notebook):
```python
# 30 lines of model loading code
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
from peft import LoraConfig, get_peft_model
MODEL_NAME = 'LazarusNLP/IndoNanoT5-base'
base_model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)
# ... 25 more lines
```

**After** (v2 notebook):
```python
# 3 lines!
from src.finetuned.utils.model_loader import load_model_with_lora
peft_model, tokenizer = load_model_with_lora()
```

## Bug Fixes Applied

### Critical Fix: `label_pad_token_id=-100`

**Location**: `src/finetuned/training/task_trainer.py`, line ~250

**Before** (BUG):
```python
data_collator = DataCollatorForSeq2Seq(
    tokenizer=self.tokenizer,
    model=self.model,
    padding=True,
    max_length=self.max_length
)
```

**After** (FIXED):
```python
data_collator = DataCollatorForSeq2Seq(
    tokenizer=self.tokenizer,
    model=self.model,
    label_pad_token_id=-100,  # ✅ CRITICAL FIX
    padding=True,
    max_length=self.max_length,
    pad_to_multiple_of=8
)
```

**Impact**:
- Training loss: 39 → 2-5 ✅
- BLEU-4: 0.005 → 0.35-0.45 ✅
- Model learns meaningful questions ✅

## Expected Results

### Before Fix:
- Training loss: ~39 (stagnant)
- BLEU-4: 0.005 (near zero)
- ROUGE-L: 0.0
- Output: Gibberish

### After Fix (v2 notebook):
- Training loss: 2-5 (normal)
- BLEU-4: 0.35-0.45 (good)
- ROUGE-L: 0.30-0.40 (good)
- Output: Meaningful Indonesian questions

## Usage

1. Upload `src_finetuned.zip` to Google Drive
2. Open `03_task_specific_training_v2.ipynb` in Colab
3. Run all cells
4. Wait ~1-2 hours for training
5. Check results in `evaluation_results/`

## Support

For issues or questions:
1. Check `docs/report.md` for configuration details
2. Check `docs/evaluasi.md` for debugging guide
3. Verify bug fix is applied in `task_trainer.py`
